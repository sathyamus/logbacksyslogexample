
package com.javacodegeeks.examples.logbacksyslogexample.message;

public interface IMessageTransmitter {

	void send( final String message );
}
