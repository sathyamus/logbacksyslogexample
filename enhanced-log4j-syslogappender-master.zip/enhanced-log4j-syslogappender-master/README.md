# enhanced-log4j-syslogappender

The standard log4j SyslogAppender has some major disadvantages when it comes to centralized logging.

Imagine the following target architecture:

App --> Central Syslog Server
